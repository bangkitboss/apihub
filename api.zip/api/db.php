<?php

$servername = "localhost";
$database = "nowsms";
$username = "bangkit";
$password = "santai";
 
$dbConn = mysqli_connect($servername, $username, $password, $database);

if ($dbConn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

function dbQuery($sql) {
	global $dbConn;
	$result = mysqli_query($dbConn, $sql) or die(mysqli_error($dbConn));
	return $result;
}

function dbFetchAssoc($result) {
	return mysqli_fetch_assoc($result);
}

function dbNumRows($result) {
    return mysqli_num_rows($result);
}

function closeConn() {
	global $dbConn;
	mysqli_close($dbConn);
}
	
//End of file